package rucc_controller_test

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"gopkg.in/yaml.v3"
)

// TestHelmLint verifies the chart passes Helm lint validation
func TestHelmLint(t *testing.T) {
	chartPath := getChartPath(t)

	cmd := exec.Command("helm", "lint", chartPath)
	output, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("helm lint failed: %v\nOutput: %s", err, string(output))
	}

	outputStr := string(output)
	// Check for actual failures (not "0 chart(s) failed")
	if strings.Contains(outputStr, "[ERROR]") || strings.Contains(outputStr, "chart(s) failed") && !strings.Contains(outputStr, "0 chart(s) failed") {
		t.Fatalf("helm lint reported failures: %s", outputStr)
	}

	t.Logf("helm lint passed: %s", outputStr)
}

// TestHelmTemplateRendering verifies the chart templates render without errors
func TestHelmTemplateRendering(t *testing.T) {
	chartPath := getChartPath(t)

	tests := []struct {
		name     string
		setFlags []string
	}{
		{
			name:     "default values",
			setFlags: []string{},
		},
		{
			name: "community edition",
			setFlags: []string{
				"--set", "settings.checks.edition=community",
				"--set", "settings.safety.edition=community",
			},
		},
		{
			name: "prime edition",
			setFlags: []string{
				"--set", "settings.checks.edition=prime",
				"--set", "settings.safety.edition=prime",
				"--set", "settings.metaServer.enabled=true",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			args := []string{"template", "test", chartPath}
			args = append(args, tt.setFlags...)

			cmd := exec.Command("helm", args...)
			output, err := cmd.CombinedOutput()
			if err != nil {
				t.Fatalf("helm template failed: %v\nOutput: %s", err, string(output))
			}

			outputStr := string(output)
			if len(outputStr) == 0 {
				t.Fatal("helm template produced no output")
			}

			t.Logf("helm template rendered %d bytes", len(outputStr))
		})
	}
}

// TestCheckRunCRDExists verifies the CheckRun CRD is present in the chart
func TestCheckRunCRDExists(t *testing.T) {
	chartPath := getChartPath(t)
	crdPath := filepath.Join(chartPath, "crds", "rucc.cattle.io_checkruns.yaml")

	if _, err := os.Stat(crdPath); os.IsNotExist(err) {
		t.Fatalf("CheckRun CRD not found at %s", crdPath)
	}

	// Read and parse the CRD
	data, err := os.ReadFile(crdPath)
	if err != nil {
		t.Fatalf("failed to read CheckRun CRD: %v", err)
	}

	var crd map[string]interface{}
	if err := yaml.Unmarshal(data, &crd); err != nil {
		t.Fatalf("failed to parse CheckRun CRD: %v", err)
	}

	// Verify it's a CRD
	kind, ok := crd["kind"].(string)
	if !ok || kind != "CustomResourceDefinition" {
		t.Fatalf("expected kind CustomResourceDefinition, got %v", kind)
	}

	// Verify the name
	metadata, ok := crd["metadata"].(map[string]interface{})
	if !ok {
		t.Fatal("metadata not found in CRD")
	}

	name, ok := metadata["name"].(string)
	if !ok || name != "checkruns.rucc.cattle.io" {
		t.Fatalf("expected name checkruns.rucc.cattle.io, got %v", name)
	}

	t.Logf("CheckRun CRD validated: %s", name)
}

// TestSettingsCRIncludesCheckFields verifies Settings CR includes edition and metaServer fields
func TestSettingsCRIncludesCheckFields(t *testing.T) {
	chartPath := getChartPath(t)

	tests := []struct {
		name              string
		setFlags          []string
		expectedEdition   string
		expectMetaServer  bool
		metaServerEnabled bool
	}{
		{
			name: "community edition",
			setFlags: []string{
				"--set", "settings.checks.edition=community",
				"--set", "settings.safety.edition=community",
			},
			expectedEdition:   "community",
			expectMetaServer:  true,
			metaServerEnabled: false,
		},
		{
			name: "prime edition with meta-server",
			setFlags: []string{
				"--set", "settings.checks.edition=prime",
				"--set", "settings.safety.edition=prime",
				"--set", "settings.metaServer.enabled=true",
			},
			expectedEdition:   "prime",
			expectMetaServer:  true,
			metaServerEnabled: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			args := []string{"template", "test", chartPath}
			args = append(args, tt.setFlags...)

			cmd := exec.Command("helm", args...)
			output, err := cmd.CombinedOutput()
			if err != nil {
				t.Fatalf("helm template failed: %v\nOutput: %s", err, string(output))
			}

			outputStr := string(output)

			// Verify Settings kind is present
			if !strings.Contains(outputStr, "kind: Settings") {
				t.Fatal("Settings CR not found in template output")
			}

			// Verify edition field for checks
			if !strings.Contains(outputStr, "edition: "+tt.expectedEdition) {
				t.Errorf("expected checks.edition=%s in Settings CR", tt.expectedEdition)
			}

			// Verify metaServer field is present
			if tt.expectMetaServer && !strings.Contains(outputStr, "metaServer:") {
				t.Error("metaServer field not found in Settings CR")
			}

			t.Logf("Settings CR validated with edition=%s", tt.expectedEdition)
		})
	}
}

// TestValuesYAMLStructure verifies the values.yaml includes required check configuration
func TestValuesYAMLStructure(t *testing.T) {
	chartPath := getChartPath(t)
	valuesPath := filepath.Join(chartPath, "values.yaml")

	data, err := os.ReadFile(valuesPath)
	if err != nil {
		t.Fatalf("failed to read values.yaml: %v", err)
	}

	var values map[string]interface{}
	if err := yaml.Unmarshal(data, &values); err != nil {
		t.Fatalf("failed to parse values.yaml: %v", err)
	}

	// Verify settings section exists
	settings, ok := values["settings"].(map[string]interface{})
	if !ok {
		t.Fatal("settings section not found in values.yaml")
	}

	// Verify checks section exists
	checks, ok := settings["checks"].(map[string]interface{})
	if !ok {
		t.Fatal("settings.checks section not found in values.yaml")
	}

	// Verify edition field exists in checks
	if _, ok := checks["edition"]; !ok {
		t.Error("settings.checks.edition not found in values.yaml")
	}

	// Verify safety section exists
	safety, ok := settings["safety"].(map[string]interface{})
	if !ok {
		t.Fatal("settings.safety section not found in values.yaml")
	}

	// Verify edition field exists in safety
	if _, ok := safety["edition"]; !ok {
		t.Error("settings.safety.edition not found in values.yaml")
	}

	// Verify metaServer section exists
	metaServer, ok := settings["metaServer"].(map[string]interface{})
	if !ok {
		t.Fatal("settings.metaServer section not found in values.yaml")
	}

	// Verify metaServer has enabled and url fields
	if _, ok := metaServer["enabled"]; !ok {
		t.Error("settings.metaServer.enabled not found in values.yaml")
	}
	if _, ok := metaServer["url"]; !ok {
		t.Error("settings.metaServer.url not found in values.yaml")
	}

	t.Log("values.yaml structure validated successfully")
}

// TestQuestionsYAMLIncludesCheckConfiguration verifies questions.yaml includes check edition questions
func TestQuestionsYAMLIncludesCheckConfiguration(t *testing.T) {
	chartPath := getChartPath(t)
	questionsPath := filepath.Join(chartPath, "questions.yaml")

	data, err := os.ReadFile(questionsPath)
	if err != nil {
		t.Fatalf("failed to read questions.yaml: %v", err)
	}

	var questions map[string]interface{}
	if err := yaml.Unmarshal(data, &questions); err != nil {
		t.Fatalf("failed to parse questions.yaml: %v", err)
	}

	// Get questions array
	questionsArray, ok := questions["questions"].([]interface{})
	if !ok {
		t.Fatal("questions array not found in questions.yaml")
	}

	// Track which required variables we found
	foundVariables := make(map[string]bool)
	requiredVariables := []string{
		"settings.checks.edition",
		"settings.safety.edition",
		"settings.metaServer.enabled",
		"settings.metaServer.url",
	}

	// Search for required variables
	for _, q := range questionsArray {
		question, ok := q.(map[string]interface{})
		if !ok {
			continue
		}

		variable, ok := question["variable"].(string)
		if !ok {
			continue
		}

		for _, required := range requiredVariables {
			if variable == required {
				foundVariables[required] = true
			}
		}
	}

	// Verify all required variables were found
	for _, required := range requiredVariables {
		if !foundVariables[required] {
			t.Errorf("required variable %s not found in questions.yaml", required)
		}
	}

	t.Logf("questions.yaml validated: found %d/%d required variables", len(foundVariables), len(requiredVariables))
}

// TestWebhookTLSManualMode verifies manual TLS mode guard and Secret/caBundle rendering.
func TestWebhookTLSManualMode(t *testing.T) { //nolint:revive // cognitive/function-length acceptable for this scope
	chartPath := getChartPath(t)

	// Minimal dummy PEM cert/key for template rendering (not cryptographically valid —
	// the template only needs non-empty strings; b64enc works on arbitrary bytes).
	fakeCrt := "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0t"
	fakeKey := "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0t"

	tests := []struct {
		name        string
		setFlags    []string
		expectError bool
		errorMsg    string
		verify      func(t *testing.T, output string)
	}{
		{
			name: "mode=manual with no certs returns required guard error",
			setFlags: []string{
				"--set", "webhook.tls.mode=manual",
				"--set", "webhook.validators.settings.enabled=true",
			},
			expectError: true,
			errorMsg:    "webhook.tls.manual.crt is required",
		},
		{
			name: "mode=manual with whitespace-only crt returns required guard error",
			setFlags: []string{
				"--set", "webhook.tls.mode=manual",
				"--set", "webhook.tls.manual.crt=   ",
				"--set", "webhook.tls.manual.key=   ",
				"--set", "webhook.validators.settings.enabled=true",
			},
			expectError: true,
			errorMsg:    "webhook.tls.manual.crt is required",
		},
		{
			name: "mode=manual with valid certs renders Secret and caBundle",
			setFlags: []string{
				"--set", "webhook.tls.mode=manual",
				"--set", "webhook.tls.manual.crt=" + fakeCrt,
				"--set", "webhook.tls.manual.key=" + fakeKey,
				"--set", "webhook.validators.settings.enabled=true",
			},
			expectError: false,
			verify: func(t *testing.T, output string) {
				if !strings.Contains(output, "kind: Secret") {
					t.Error("expected Secret resource in manual TLS mode output")
				}
				if !strings.Contains(output, "certificate-mode: \"manual\"") {
					t.Error("expected manual certificate-mode annotation in Secret")
				}
				if !strings.Contains(output, "caBundle:") {
					t.Error("expected caBundle field in ValidatingAdmissionWebhookConfiguration")
				}
			},
		},
		{
			name: "mode=manual with existingSecret renders caBundle from caBundle field",
			setFlags: []string{
				"--set", "webhook.tls.mode=manual",
				"--set", "webhook.tls.manual.existingSecret=my-tls-secret",
				"--set", "webhook.tls.manual.caBundle=" + fakeCrt,
				"--set", "webhook.validators.settings.enabled=true",
			},
			expectError: false,
			verify: func(t *testing.T, output string) {
				// No Secret should be created when existingSecret is set
				if strings.Contains(output, "certificate-mode: \"manual\"") {
					t.Error("should NOT create a new Secret when existingSecret is set")
				}
				if !strings.Contains(output, "caBundle:") {
					t.Error("expected caBundle field when existingSecret is set")
				}
			},
		},
		{
			name: "mode=autoGenerate regression — guards do not fire",
			setFlags: []string{
				"--set", "webhook.tls.mode=autoGenerate",
				"--set", "webhook.validators.settings.enabled=true",
			},
			expectError: false,
			verify: func(t *testing.T, output string) {
				if !strings.Contains(output, "certificate-mode: \"autoGenerate\"") {
					t.Error("expected autoGenerate certificate-mode annotation in Secret")
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			args := []string{"template", "test", chartPath}
			args = append(args, tt.setFlags...)

			cmd := exec.Command("helm", args...)
			output, err := cmd.CombinedOutput()
			outputStr := string(output)

			if tt.expectError {
				if err == nil {
					t.Fatalf("expected helm template to fail with %q but it succeeded\nOutput: %s",
						tt.errorMsg, outputStr)
				}
				if tt.errorMsg != "" && !strings.Contains(outputStr, tt.errorMsg) {
					t.Errorf("expected error containing %q\nGot: %s", tt.errorMsg, outputStr)
				}
				return
			}

			if err != nil {
				t.Fatalf("helm template failed unexpectedly: %v\nOutput: %s", err, outputStr)
			}

			if tt.verify != nil {
				tt.verify(t, outputStr)
			}
		})
	}
}

// getChartPath returns the absolute path to the chart directory
func getChartPath(t *testing.T) string {
	t.Helper()

	// Get current working directory
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatalf("failed to get working directory: %v", err)
	}

	// Chart is in the same directory as this test file
	chartPath := cwd

	// Verify Chart.yaml exists
	chartYamlPath := filepath.Join(chartPath, "Chart.yaml")
	if _, err := os.Stat(chartYamlPath); os.IsNotExist(err) {
		t.Fatalf("Chart.yaml not found at %s", chartYamlPath)
	}

	return chartPath
}

// TestImageVerificationRegistries asserts the chart's imageVerification.registries
// stanza lists only canonical RUCC registries — no personal/developer registries
// (e.g. cube8021/*) — and that the canonical entries are enforced with
// required: true and keyless: true. (rucc-217)
//
// The check reads values.yaml directly rather than going through helm template
// because the registries block is consumed by the controller's verification
// pipeline straight from values, not rendered into a templated manifest.
func TestImageVerificationRegistries(t *testing.T) { //nolint:revive // cognitive/function-length acceptable for this scope
	chartPath := getChartPath(t)
	valuesPath := filepath.Join(chartPath, "values.yaml")

	data, err := os.ReadFile(valuesPath)
	if err != nil {
		t.Fatalf("failed to read values.yaml: %v", err)
	}

	// Cheap textual scan first: cube8021 must not appear anywhere in values.yaml.
	// This catches both the registries entry and any stale comment references —
	// belt-and-suspenders for the audit. (rucc-216/rucc-217)
	if strings.Contains(string(data), "cube8021") {
		t.Errorf("values.yaml contains 'cube8021' references; canonical chart defaults must use only rancher/* and rancherlabs/* registries")
	}

	var values map[string]interface{}
	if err := yaml.Unmarshal(data, &values); err != nil {
		t.Fatalf("failed to parse values.yaml: %v", err)
	}

	iv, ok := values["imageVerification"].(map[string]interface{})
	if !ok {
		t.Fatal("imageVerification section not found in values.yaml")
	}

	registriesRaw, ok := iv["registries"].([]interface{})
	if !ok {
		t.Fatal("imageVerification.registries not found or wrong type in values.yaml")
	}
	if len(registriesRaw) == 0 {
		t.Fatal("imageVerification.registries is empty; expected canonical entries")
	}

	// Canonical patterns that MUST be present, each with required: true AND keyless: true.
	requiredCanonicalPatterns := []string{
		"ghcr.io/rancherlabs/rucc/*",
		"docker.io/rancher/rucc/*",
	}
	canonicalPrefixes := []string{
		"ghcr.io/rancherlabs/rucc/",
		"docker.io/rancher/rucc/",
	}
	found := make(map[string]bool, len(requiredCanonicalPatterns))

	for i, raw := range registriesRaw {
		entry, ok := raw.(map[string]interface{})
		if !ok {
			t.Errorf("imageVerification.registries[%d] is not a mapping (got %T)", i, raw)
			continue
		}

		patternIface, ok := entry["pattern"]
		if !ok {
			t.Errorf("imageVerification.registries[%d] missing pattern field", i)
			continue
		}
		pattern, ok := patternIface.(string)
		if !ok {
			t.Errorf("imageVerification.registries[%d] pattern is not a string (got %T)", i, patternIface)
			continue
		}

		// ABSENCE assertion: no entry may reference a personal/dev registry.
		if strings.Contains(pattern, "cube8021") {
			t.Errorf("imageVerification.registries[%d] pattern %q references a personal registry; chart defaults must be canonical only (rucc-217)",
				i, pattern)
		}

		// Every entry must belong to a known canonical prefix.
		isCanonical := false
		for _, prefix := range canonicalPrefixes {
			if strings.HasPrefix(pattern, prefix) {
				isCanonical = true
				break
			}
		}
		if !isCanonical {
			t.Errorf("imageVerification.registries[%d] pattern %q is not a canonical RUCC registry pattern; allowed prefixes: %v",
				i, pattern, canonicalPrefixes)
		}

		// Track canonical patterns we've seen.
		for _, want := range requiredCanonicalPatterns {
			if pattern == want {
				found[want] = true

				// Each canonical entry MUST be required:true AND keyless:true.
				required, _ := entry["required"].(bool)
				keyless, _ := entry["keyless"].(bool)
				if !required {
					t.Errorf("imageVerification.registries[%d] pattern %q must have required: true (got %v)", i, pattern, entry["required"])
				}
				if !keyless {
					t.Errorf("imageVerification.registries[%d] pattern %q must have keyless: true (got %v)", i, pattern, entry["keyless"])
				}
			}
		}
	}

	// PRESENCE assertion: every canonical pattern must be in the list.
	for _, want := range requiredCanonicalPatterns {
		if !found[want] {
			t.Errorf("imageVerification.registries is missing canonical entry %q", want)
		}
	}

	t.Logf("validated imageVerification.registries: %d entries, all canonical, required+keyless enforced", len(registriesRaw))
}
