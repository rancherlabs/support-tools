# RUCC Controller Prerequisite Check

The RUCC controller includes an automatic prerequisite check that runs as a Helm pre-install/pre-upgrade hook. This ensures all required services are deployed and ready before the RUCC controller starts.

## What It Checks

### Required Prerequisites (Installation will fail if missing)

1. **Rancher Management Server**
   - Namespace: `cattle-system`
   - Deployment: `rancher`
   - Verifies: Deployment exists and all replicas are ready
   - Verifies: At least one Rancher pod is running

2. **System Upgrade Controller**
   - Namespace: `cattle-system`
   - Deployment: `system-upgrade-controller`
   - CRD: `plans.upgrade.cattle.io`
   - Verifies: Deployment exists and replicas are ready
   - Verifies: SUC CRDs are installed

3. **Rancher Backup Operator**
   - Namespace: `cattle-resources-system`
   - Deployment: `rancher-backup`
   - CRDs: `backups.resources.cattle.io`, `restores.resources.cattle.io`
   - Verifies: Deployment exists and replicas are ready
   - Verifies: Backup/Restore CRDs are installed

## How It Works

The prerequisite check runs as a Kubernetes Job with these characteristics:

- **Hook Type**: `pre-install`, `pre-upgrade`
- **Hook Weight**: `-5` (runs before other resources)
- **Hook Delete Policy**: `before-hook-creation`, `hook-succeeded`
- **Timeout**: 300 seconds (5 minutes)
- **Retries**: 3 attempts

The job uses the `rancher/kubectl` image to run checks against the Kubernetes API.

## Configuration

### Enable/Disable the Check

```yaml
prerequisiteCheck:
  enabled: true  # Set to false to skip checks
```

### Configure Required vs Optional Checks

```yaml
prerequisiteCheck:
  rancher:
    enabled: true
    required: true  # Fail if not found

  systemUpgradeController:
    enabled: true
    required: true  # Fail if not found

  rancherBackup:
    enabled: true
    required: true  # Fail if not found
```

### Customize Timeout and Retries

```yaml
prerequisiteCheck:
  timeout: 300  # Total timeout in seconds
  backoffLimit: 3  # Number of retry attempts
```

## Example Output

### ✅ Success (All Prerequisites Ready)

```
==============================================
RUCC Controller Prerequisite Check
==============================================

=== Required Prerequisites ===

Checking Rancher Management Server... ✓ OK (3/3 replicas ready)
Checking Rancher pods... ✓ OK (3 pod(s) running)
Checking System Upgrade Controller... ✓ OK (1/1 replicas ready)
Checking System Upgrade Controller CRD... ✓ OK
Checking Rancher Backup Operator... ✓ OK (1/1 replicas ready)
Checking Rancher Backup CRD... ✓ OK
Checking Rancher Restore CRD... ✓ OK

==============================================
Prerequisite Check Results
==============================================
✓ SUCCESS: All prerequisites are ready
```

### ❌ Failure (Required Prerequisites Missing)

```
==============================================
RUCC Controller Prerequisite Check
==============================================

=== Required Prerequisites ===

Checking Rancher Management Server... ✓ OK (3/3 replicas ready)
Checking System Upgrade Controller... ✗ NOT FOUND
Checking Rancher Backup Operator... ✗ NOT FOUND

==============================================
Prerequisite Check Results
==============================================
✗ FAILED: One or more required prerequisites are missing or not ready

Please ensure the following are installed and ready:
  - System Upgrade Controller (cattle-system namespace)
  - Rancher Backup Operator (cattle-resources-system namespace)

For installation instructions, visit:
  https://ranchermanager.docs.rancher.com/
```

## Troubleshooting

### Check Job Logs

If the prerequisite check fails, view the job logs:

```bash
kubectl logs -n cattle-system job/rucc-controller-prerequisite-check
```

### Manual Check

Run a manual check to see the current state:

```bash
# Check Rancher
kubectl get deployment rancher -n cattle-system

# Check System Upgrade Controller
kubectl get deployment system-upgrade-controller -n cattle-system

# Check Rancher Backup Operator
kubectl get deployment rancher-backup -n cattle-resources-system

# Check CRDs
kubectl get crd plans.upgrade.cattle.io
kubectl get crd backups.resources.cattle.io
kubectl get crd restores.resources.cattle.io
```

### Skip Prerequisite Checks (Not Recommended)

If you need to bypass the checks (for testing only):

```bash
helm install rucc-controller . \
  --set prerequisiteCheck.enabled=false
```

Or disable specific checks:

```bash
helm install rucc-controller . \
  --set prerequisiteCheck.systemUpgradeController.required=false \
  --set prerequisiteCheck.rancherBackup.required=false
```

## Installation Order

For a fresh installation, install components in this order:

1. **Rancher** (if not already installed)
   ```bash
   helm install rancher rancher-latest/rancher \
     --namespace cattle-system \
     --create-namespace
   ```

2. **System Upgrade Controller**
   ```bash
   kubectl apply -f https://github.com/rancher/system-upgrade-controller/releases/latest/download/system-upgrade-controller.yaml
   ```

3. **Rancher Backup Operator** (via Rancher UI or Helm)
   ```bash
   helm install rancher-backup-crd rancher-charts/rancher-backup-crd \
     --namespace cattle-resources-system \
     --create-namespace

   helm install rancher-backup rancher-charts/rancher-backup \
     --namespace cattle-resources-system
   ```

4. **RUCC Controller**
   ```bash
   helm install rucc-controller ./rucc-controller \
     --namespace cattle-system
   ```

## RBAC Requirements

The prerequisite check job uses the RUCC controller's service account, which requires these permissions:

- Read deployments in all namespaces
- Read pods in all namespaces
- Read CRDs cluster-wide

These permissions are included when `rbac.clusterAdmin=true` (default).

## Security

The prerequisite check job runs with these security constraints:

- Non-root user (UID 65532)
- Read-only root filesystem
- All capabilities dropped
- No privilege escalation
- Runs in the `cattle-system` namespace
- Uses Kubernetes `RuntimeDefault` seccomp profile
