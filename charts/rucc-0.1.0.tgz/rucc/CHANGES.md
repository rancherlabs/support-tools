# RUCC Controller Helm Chart Changes

## Recent Updates

### Prerequisite Check Feature (2025-10-02)

Added automatic prerequisite validation to ensure required services are deployed before RUCC controller installation.

#### New Files
- `templates/prerequisite-check.yaml` - Pre-install/pre-upgrade hook job that validates prerequisites
- `PREREQUISITE_CHECK.md` - Comprehensive documentation for the prerequisite check feature

#### Modified Files

**values.yaml**
- Added `prerequisiteCheck` section with configuration for:
  - Rancher Management Server validation
  - System Upgrade Controller validation
  - Rancher Backup Operator validation
  - cert-manager validation (optional)
  - Prometheus Operator validation (optional)

**questions.yaml** (Streamlined)
- Reorganized to focus on essential configuration
- Added "Prerequisite Checks" group with options to:
  - Enable/disable prerequisite checking
  - Configure which services are required vs optional
- Improved organization with clear section separators
- Updated default values to production-ready settings:
  - `image.tag` defaults to empty (uses Chart appVersion)
  - `image.pullPolicy` defaults to "IfNotPresent"
  - Edition defaults to "community"
  - Meta-Server URL uses production URL

#### How It Works

The prerequisite check runs as a Kubernetes Job with:
- **Hook**: `pre-install`, `pre-upgrade`
- **Weight**: `-5` (runs before other resources)
- **Delete Policy**: `before-hook-creation`, `hook-succeeded`
- **Timeout**: 300 seconds
- **Retries**: 3 attempts

The check validates:

**Required Prerequisites** (fail installation if missing):
1. Rancher Management Server (deployment + pods)
2. System Upgrade Controller (deployment + CRDs)
3. Rancher Backup Operator (deployment + CRDs)

#### Configuration Examples

**Enable all checks (default)**:
```yaml
prerequisiteCheck:
  enabled: true
  rancher:
    required: true
  systemUpgradeController:
    required: true
  rancherBackup:
    required: true
```

**Make backup optional**:
```yaml
prerequisiteCheck:
  enabled: true
  rancherBackup:
    required: false  # Warn instead of fail
```

**Disable prerequisite checks** (not recommended):
```yaml
prerequisiteCheck:
  enabled: false
```

#### Benefits

1. **Prevents Failed Installations** - Catches missing prerequisites before installation
2. **Clear Error Messages** - Shows exactly what's missing and how to fix it
3. **Configurable** - Can adjust which checks are required vs optional
4. **Secure** - Runs with minimal permissions and security constraints
5. **Non-invasive** - Automatically cleans up after success

#### Rancher UI Integration

Users installing via Rancher Apps & Marketplace will see:
- "Prerequisite Checks" section in the installation form
- Options to enable/disable individual checks
- Options to make services required or optional

#### Testing

```bash
# Validate the chart
helm lint /path/to/rucc-controller

# Dry run to see what would be created
helm install rucc-controller . --dry-run --debug

# Test prerequisite check specifically
helm template test . --show-only templates/prerequisite-check.yaml
```

#### Troubleshooting

If installation fails due to prerequisites:

1. **View job logs**:
   ```bash
   kubectl logs -n cattle-system job/rucc-controller-prerequisite-check
   ```

2. **Check job status**:
   ```bash
   kubectl get job -n cattle-system rucc-controller-prerequisite-check
   ```

3. **Install missing prerequisites**:
   - See `PREREQUISITE_CHECK.md` for installation order

#### Security Considerations

The prerequisite check job:
- Runs as non-root user (UID 65532)
- Uses read-only root filesystem
- Drops all capabilities
- Prevents privilege escalation
- Uses Kubernetes RuntimeDefault seccomp profile
- Requires only read permissions for validation

---

## Previous Changes

### Questions.yaml Cleanup
- Streamlined from 589 lines to 398 lines
- Focused on essential Settings CR configuration
- Removed low-level controller tuning options
- Organized into logical groups
- Improved descriptions and defaults
