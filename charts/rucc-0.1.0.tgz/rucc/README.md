# RUCC Controller Helm Chart

Official Helm chart for installing the RUCC Controller on Kubernetes clusters.

## Overview

The RUCC Controller is a Kubernetes-native controller that orchestrates safe, automated upgrades for Rancher management clusters and their underlying RKE2 infrastructure.

## Prerequisites

- Kubernetes v1.25+ (recommended: v1.28+)
- Helm 3.10+
- cert-manager v1.12+ (for webhooks and TLS)
- Access to RUCC Meta-Server (self-hosted or SaaS)

## Quick Installation

```bash
# Add Helm repository (when available)
helm repo add rucc https://charts.support.tools/
helm repo update

# Install RUCC Controller
helm install rucc-controller rucc/rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --set metaServer.url=https://rucc.rancher.io
```

## Configuration

### Basic Configuration

```yaml
# values.yaml
image:
  repository: ghcr.io/rancherlabs/rucc/rucc-controller
  tag: "latest"
  pullPolicy: IfNotPresent

# Meta-Server connection
metaServer:
  url: "https://rucc.rancher.io"
  timeout: "30s"

# Controller settings
controller:
  logLevel: info
  development: false
```

### Production Configuration

```yaml
# Production values
replicaCount: 2

resources:
  limits:
    cpu: 1000m
    memory: 512Mi
  requests:
    cpu: 200m
    memory: 256Mi

# High availability
podDisruptionBudget:
  enabled: true
  minAvailable: 1

# Security
securityContext:
  runAsNonRoot: true
  runAsUser: 65532
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false

# Monitoring
monitoring:
  enabled: true
  serviceMonitor:
    enabled: true

# Network security
networkPolicy:
  enabled: true
```

### Check Configuration

RUCC Controller v2.1.0+ includes pluggable check architecture with two editions:

#### Community Edition (Default)
Built-in checks compiled into the controller:
- **Pre-upgrade checks**: 13 checks (version compatibility, Kubernetes health, certificates, etc.)
- **Post-upgrade checks**: 4 checks (health validation, API accessibility, etc.)

```yaml
settings:
  checks:
    edition: community
  safety:
    edition: community
    requirePreChecks: true
    requirePostChecks: true
```

#### Prime Edition
Built-in checks + Meta-Server provided checks:
- **Pre-upgrade checks**: 23+ checks (includes Community + advanced Prime checks)
- **Post-upgrade checks**: 6+ checks (includes Community + advanced Prime checks)

```yaml
settings:
  checks:
    edition: prime
  safety:
    edition: prime
  metaServer:
    enabled: true
    url: "https://rucc.rancher.io"
```

#### Testing Checks with CheckRun CRD

The CheckRun CRD allows dry-run testing of checks before actual upgrades:

```yaml
apiVersion: rucc.cattle.io/v1alpha1
kind: CheckRun
metadata:
  name: pre-upgrade-test
  namespace: cattle-system
spec:
  checkType: pre-check
  upgradeType: rancher
  edition: community
  targetVersion: "2.9.3"
  timeout: 10m
```

View example CheckRun manifests in the `examples/` directory:
- `checkrun-rancher-pre-check.yaml` - Rancher pre-upgrade checks
- `checkrun-rancher-post-check-prime.yaml` - Rancher post-upgrade checks (Prime)
- `checkrun-rke2-pre-check.yaml` - RKE2 pre-upgrade checks
- `checkrun-common-health.yaml` - Common health checks

See [DRY_RUN_GUIDE.md](../../docs/DRY_RUN_GUIDE.md) for detailed CheckRun usage.

### Advanced Configuration

```yaml
# Leader election
leaderElection:
  enabled: true
  leaseDuration: "15s"
  renewDeadline: "10s"
  retryPeriod: "2s"

# Custom resource management
crds:
  install: true
  keep: false

# Webhook configuration
webhook:
  enabled: true
  service:
    port: 9443  # configurable via webhook.service.port (default 9443)
  tls:
    mode: autoGenerate  # autoGenerate | certManager | manual

# Node affinity
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        labelSelector:
          matchExpressions:
          - key: app.kubernetes.io/name
            operator: In
            values:
            - rucc-controller
        topologyKey: kubernetes.io/hostname
```

## Configuration Parameters

### Image Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Controller image repository | `ghcr.io/rancherlabs/rucc/rucc-controller` |
| `image.tag` | Image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `imagePullSecrets` | Image pull secrets | `[]` |

### Deployment Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `1` |
| `resources.limits.cpu` | CPU limit | `500m` |
| `resources.limits.memory` | Memory limit | `256Mi` |
| `resources.requests.cpu` | CPU request | `100m` |
| `resources.requests.memory` | Memory request | `128Mi` |

### Controller Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `controller.logLevel` | Log level (debug, info, warn, error) | `info` |
| `controller.development` | Enable development mode | `false` |
| `metaServer.url` | Meta-Server URL | `""` |
| `metaServer.timeout` | Meta-Server request timeout | `30s` |

### Check Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `settings.checks.edition` | Check edition (community, prime) | `prime` |
| `settings.safety.edition` | Safety check edition (community, prime) | `community` |
| `settings.metaServer.enabled` | Enable Meta-Server for Prime checks | `false` |
| `settings.metaServer.url` | Meta-Server URL for check catalog | `https://rucc.rancher.io` |
| `settings.checks.preUpgrade.enabled` | Enable pre-upgrade checks | `true` |
| `settings.checks.postUpgrade.enabled` | Enable post-upgrade checks | `true` |

### Security Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `securityContext.runAsNonRoot` | Run as non-root user | `true` |
| `securityContext.runAsUser` | User ID to run as | `65532` |
| `securityContext.readOnlyRootFilesystem` | Read-only root filesystem | `true` |
| `networkPolicy.enabled` | Enable network policies | `false` |

### Monitoring Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `monitoring.enabled` | Enable metrics endpoint | `true` |
| `monitoring.port` | Metrics port | `8080` |
| `serviceMonitor.enabled` | Create ServiceMonitor | `false` |
| `serviceMonitor.interval` | Scrape interval | `30s` |

### High Availability Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `podDisruptionBudget.enabled` | Enable PDB | `false` |
| `podDisruptionBudget.minAvailable` | Minimum available pods | `1` |
| `autoscaling.enabled` | Enable HPA | `false` |
| `autoscaling.minReplicas` | Minimum replicas | `2` |
| `autoscaling.maxReplicas` | Maximum replicas | `5` |

## Installation Examples

### Development Installation

```bash
helm install rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --set image.tag=latest \
  --set controller.logLevel=debug \
  --set controller.development=true \
  --set metaServer.url=http://localhost:8080
```

### Production Installation

```bash
helm install rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --values production-values.yaml \
  --wait
```

### Community Edition Installation

```bash
helm install rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --set settings.checks.edition=community \
  --set settings.safety.edition=community
```

### Prime Edition Installation

```bash
helm install rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --set settings.checks.edition=prime \
  --set settings.safety.edition=prime \
  --set settings.metaServer.enabled=true \
  --set settings.metaServer.url=https://rucc.rancher.io
```

### Air-gapped Installation

```bash
# Pull and push images to private registry first
docker pull ghcr.io/rancherlabs/rucc/rucc-controller:v1.0.0
docker tag ghcr.io/rancherlabs/rucc/rucc-controller:v1.0.0 my-registry.com/rucc-controller:v1.0.0
docker push my-registry.com/rucc-controller:v1.0.0

# Install with private registry
helm install rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --set image.repository=my-registry.com/rucc-controller \
  --set image.tag=v1.0.0
```

## Upgrading

### Minor Version Updates

```bash
# Update Helm repository
helm repo update

# Upgrade to latest version
helm upgrade rucc-controller rucc/rucc-controller \
  --namespace cattle-system \
  --reuse-values
```

### Major Version Updates

```bash
# Check for breaking changes in CHANGELOG.md
# Backup current configuration
helm get values rucc-controller -n cattle-system > current-values.yaml

# Perform upgrade
helm upgrade rucc-controller rucc/rucc-controller \
  --namespace cattle-system \
  --values current-values.yaml \
  --wait
```

## Troubleshooting

### Installation Issues

```bash
# Check Helm release status
helm status rucc-controller -n cattle-system

# View release history
helm history rucc-controller -n cattle-system

# Check pod status
kubectl get pods -n cattle-system -l app.kubernetes.io/name=rucc-controller

# View pod logs
kubectl logs -n cattle-system -l app.kubernetes.io/name=rucc-controller
```

### Configuration Issues

```bash
# Validate values
helm template rucc-controller ./rucc-controller \
  --values my-values.yaml \
  --debug > rendered.yaml

# Check current configuration
helm get values rucc-controller -n cattle-system

# Test configuration changes
helm upgrade rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --values my-values.yaml \
  --dry-run
```

### Common Issues

#### 1. CRDs Not Found
```bash
# Manually install CRDs
kubectl apply -f crds/

# Or enable CRD installation
helm upgrade rucc-controller ./rucc-controller \
  --set crds.install=true
```

#### 2. RBAC Issues
```bash
# Check service account
kubectl get sa rucc-controller -n cattle-system

# Check role bindings
kubectl get clusterrolebinding | grep rucc-controller
```

#### 3. Meta-Server Connection
```bash
# Test connectivity
kubectl exec -n cattle-system deployment/rucc-controller -- \
  curl -v $RUCC_META_SERVER_URL/health
```

## Uninstallation

### Standard Uninstall

```bash
# Remove Helm release
helm uninstall rucc-controller -n cattle-system

# Optionally remove CRDs (this deletes all upgrade data!)
kubectl delete crd upgrades.rucc.cattle.io
kubectl delete crd settings.rucc.cattle.io
kubectl delete crd metaservercaches.rucc.cattle.io
```

### Complete Cleanup

```bash
# Remove all RUCC resources
kubectl delete upgrade --all -A
kubectl delete settings --all -A
kubectl delete metaservercache --all -A

# Remove CRDs
kubectl delete crd -l app.kubernetes.io/name=rucc-controller

# Remove namespace if empty
kubectl delete namespace cattle-system
```

## Development

### Local Development

```bash
# Install from local chart
helm install rucc-controller ./rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --set image.pullPolicy=Never \
  --set image.tag=local-dev

# Enable debug mode
helm upgrade rucc-controller ./rucc-controller \
  --set controller.logLevel=debug \
  --set controller.development=true
```

### Chart Testing

```bash
# Lint chart
helm lint rucc-controller/

# Test template rendering
helm template rucc-controller ./rucc-controller \
  --values test-values.yaml

# Run chart tests (if available)
helm test rucc-controller -n cattle-system
```

## Support

- **Documentation**: [RUCC Documentation](https://github.com/rancherlabs/rucc/docs)
- **Issues**: [GitHub Issues](https://github.com/rancherlabs/rucc/issues)
- **Community**: [Rancher Community](https://community.rancher.com/)

## License

This chart is licensed under the Apache 2.0 License. See [LICENSE](../../../LICENSE) for details.