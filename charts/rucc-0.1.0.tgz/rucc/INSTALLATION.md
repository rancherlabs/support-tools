# RUCC Controller Helm Chart Installation Guide

This document outlines the process of installing the RUCC (Rancher Upgrade Cruise Control) using its Helm chart.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Installation Steps](#installation-steps)
- [Configuration Options](#configuration-options)
- [Verification](#verification)
- [Upgrading](#upgrading)
- [Uninstallation](#uninstallation)
- [Troubleshooting](#troubleshooting)

## Prerequisites

To get started, you'll need the following:

### Required Components

1. **Kubernetes Cluster**: A running RKE2 Kubernetes cluster (version 1.26 or newer recommended)
2. **Helm**: Helm client (version 3.x or newer) installed. Installation instructions are available on the [Helm website](https://helm.sh/docs/intro/install/)
3. **kubectl**: The Kubernetes command-line tool, installed and configured to connect to your cluster
4. **Rancher**: A running Rancher v2.8.0 or higher
5. **Rancher Backup Operator**: Installed and configured. See [Rancher Backup/Restore Documentation](https://ranchermanager.docs.rancher.com/how-to-guides/new-user-guides/backup-restore-and-disaster-recovery)

### Permissions

- Cluster administrator access to the Kubernetes cluster
- Ability to create cluster-wide resources (ClusterRole, ClusterRoleBinding, CRDs)

### Network Requirements

- Access to container image registry (default: `ghcr.io/rancherlabs/rucc/rucc-controller`)
- Access to RUCC Meta-Server (default: `https://rucc.rancher.io`)

## Installation Steps

### 1. Add the RUCC Helm Repository

First, add the repository where the RUCC Controller Helm chart is hosted:

```bash
helm repo add supporttools https://charts.support.tools
helm repo update
```

### 2. Create Namespace (if not exists)

The RUCC Controller is typically installed in the `cattle-system` namespace:

```bash
kubectl create namespace cattle-system --dry-run=client -o yaml | kubectl apply -f -
```

### 3. Install the RUCC Controller

#### Option A: Basic Installation with Defaults

Deploy the controller with default values:

```bash
helm install rucc-controller supporttools/rucc-controller \
  --namespace cattle-system \
  --create-namespace
```

#### Option B: Installation with Custom Values

Create a custom values file (`my-values.yaml`) and install:

```bash
helm install rucc-controller supporttools/rucc-controller \
  --namespace cattle-system \
  --create-namespace \
  --values my-values.yaml
```

#### Option C: Installation via Rancher UI

1. Navigate to **Apps** → **Charts** in the Rancher UI
2. Search for "RUCC Controller"
3. Click **Install**
4. Fill out the configuration form (see [Configuration Options](#configuration-options))
5. Click **Install** to deploy

### 4. Verify Installation

Check that the RUCC Controller pod is running:

```bash
kubectl get pods -n cattle-system -l app.kubernetes.io/name=rucc-controller
```

Expected output:
```
NAME                               READY   STATUS    RESTARTS   AGE
rucc-controller-xxxxxxxxxx-xxxxx   1/1     Running   0          2m
```

Check the controller logs:

```bash
kubectl logs -n cattle-system -l app.kubernetes.io/name=rucc-controller --tail=50
```

Verify CRDs are installed:

```bash
kubectl get crd | grep rucc.cattle.io
```

Expected CRDs:
- `backups.rucc.cattle.io` — records pre-upgrade backup operations; the `spec.backupType` field accepts three values: `etcd-snapshot` (RKE2 ETCD snapshot via a per-node Job), `rancher-backup` (Rancher Backup Operator CR), or `comprehensive` (both ETCD snapshot and Rancher Backup run together); created automatically before each upgrade
- `checkruns.rucc.cattle.io` — enables dry-run execution of pre/post-upgrade health checks without an active upgrade; useful for validation and troubleshooting
- `deploymentmonitors.rucc.cattle.io` — tracks Kubernetes Deployment rollout progress; monitors pod status, replica counts, and detects crashloops during Rancher upgrades
- `helmoperationmonitors.rucc.cattle.io` — monitors Helm install/upgrade jobs and pods via label selectors; used during Rancher chart upgrades to detect failures early
- `metaservercaches.rucc.cattle.io` — caches channel, version, and support-matrix data fetched from the RUCC meta-server; reduces meta-server load and enables offline operation
- `rke2upgrademonitors.rucc.cattle.io` — tracks per-node RKE2/K3s upgrade progress via the System Upgrade Controller (SUC) Plan; reports individual node states
- `restoreoperations.rucc.cattle.io` — multi-node RKE2 etcd snapshot restore state machine (rucc-97); drives the RestoreOperation phases (Pending → Quiescing → Restoring → Resyncing → StartingPrimary → StartingSecondaries → Verifying → Completed)
- `restoreoperationhistories.rucc.cattle.io` — immutable audit artifact recording a completed RestoreOperation (original spec, signed PhasePlan, per-node final phases, union event log, forensic hashes)
- `rollbackoperations.rucc.cattle.io` — tracks rollback execution when an upgrade fails; records rollback state and completion status
- `settings.rucc.cattle.io` — controller-wide configuration (edition, channel, safety policy, auto-upgrade settings); one instance named `global` per cluster
- `upgradecampaigns.rucc.cattle.io` — orchestrates a sequenced set of upgrade steps (Rancher, RKE2, etc.) within a cluster; supports auto-approve and pause controls
- `upgrades.rucc.cattle.io` — primary resource representing a single upgrade operation for Rancher or RKE2; drives the 6-phase upgrade lifecycle

Verify the global Settings resource was created:

```bash
kubectl get settings.rucc.cattle.io -n cattle-system
```

## Configuration Options

### Essential Configuration

The following are the most important configuration options you may want to customize:

#### Edition and Channel

```yaml
settings:
  edition: "prime"              # Options: prime, standard
  channel: "Prime-Test"         # Options: Prime-Test, Prime-Stable, etc.
```

#### Meta-Server Configuration

```yaml
controller:
  metaServer:
    url: "https://rucc.rancher.io"
    timeout: "120s"
    insecureSkipVerify: true    # Only for lab/testing environments
    maxRetries: 5
    retryDelay: "5s"
```

#### Environment Settings

```yaml
labEnvironment: true            # Enable lab/development mode
controller:
  environment: "development"    # Options: development, production
hostNetwork: true              # Use host networking (useful for labs)
```

#### Resource Limits

```yaml
resources:
  limits:
    cpu: 500m
    memory: 256Mi
  requests:
    cpu: 200m
    memory: 128Mi
```

#### Safety Settings

```yaml
settings:
  safety:
    requireBackupBeforeUpgrade: true
    requirePreChecks: true
    requirePostChecks: true
    stopOnFirstError: false
```

#### Auto-Upgrade Settings

```yaml
settings:
  autoUpgrade:
    enabled: true
    checkInterval: 2m
    maxCampaigns: 3
    dryRun: false
```

### Example Custom Values File

Create a file named `my-values.yaml`:

```yaml
# Basic Configuration
image:
  repository: ghcr.io/rancherlabs/rucc/rucc-controller
  tag: latest
  pullPolicy: Always

# Environment
labEnvironment: true
hostNetwork: true

# Meta-Server
controller:
  metaServer:
    url: "https://rucc.rancher.io"
    timeout: "120s"
    insecureSkipVerify: true
  environment: "development"

# Settings
settings:
  create: true
  edition: "prime"
  channel: "Prime-Test"
  tosAccepted: true

  autoUpgrade:
    enabled: true
    checkInterval: 2m
    maxCampaigns: 3

  safety:
    requireBackupBeforeUpgrade: true
    requirePreChecks: true
    requirePostChecks: true

# Resources
resources:
  limits:
    cpu: 500m
    memory: 256Mi
  requests:
    cpu: 200m
    memory: 128Mi

# Monitoring
monitoring:
  enabled: true
  serviceMonitor:
    enabled: true
  grafanaDashboard:
    enabled: true
```

Then install with:

```bash
helm install rucc-controller supporttools/rucc-controller \
  --namespace cattle-system \
  --values my-values.yaml
```

## Verification

### 1. Check Controller Health

```bash
# Check health endpoint
kubectl port-forward -n cattle-system svc/rucc-controller 8081:8081
curl http://localhost:8081/healthz
# Expected: {"status":"ok"}
```

### 2. Check Metrics

```bash
# Check metrics endpoint
kubectl port-forward -n cattle-system svc/rucc-controller 8080:8080
curl http://localhost:8080/metrics
# Expected: Prometheus metrics output
```

### 3. Verify Global Settings

```bash
kubectl get settings.rucc.cattle.io global -n cattle-system -o yaml
```

Check that the settings reflect your configuration.

### 4. Check RBAC

```bash
# Verify ClusterRole
kubectl get clusterrole rucc-controller

# Verify ClusterRoleBinding
kubectl get clusterrolebinding rucc-controller

# Verify ServiceAccount
kubectl get serviceaccount rucc-controller -n cattle-system
```

### 5. Test Meta-Server Connectivity

Check the controller logs to ensure it can reach the meta-server:

```bash
kubectl logs -n cattle-system -l app.kubernetes.io/name=rucc-controller | grep -i "meta-server"
```

Look for successful connection messages.

## Upgrading

### Upgrade to Latest Version

```bash
# Update repository
helm repo update

# Upgrade the release
helm upgrade rucc-controller supporttools/rucc-controller \
  --namespace cattle-system \
  --reuse-values
```

### Upgrade with New Values

```bash
helm upgrade rucc-controller supporttools/rucc-controller \
  --namespace cattle-system \
  --values my-values.yaml
```

### Upgrade Specific Chart Version

```bash
helm upgrade rucc-controller supporttools/rucc-controller \
  --namespace cattle-system \
  --version 1.0.0 \
  --reuse-values
```

### Check Upgrade Status

```bash
helm status rucc-controller -n cattle-system
```

## Uninstallation

### Remove RUCC Controller

```bash
helm uninstall rucc-controller --namespace cattle-system
```

### Remove CRDs (Optional)

> **Why this step is manual**: Helm 3 intentionally **never** removes CRDs during
> `helm uninstall`. This is a deliberate Helm design choice to protect your data —
> deleting a CRD also deletes every CustomResource of that type, which could destroy
> upgrade history, campaign state, and settings that are not easily reconstructed.
> Because Helm does not handle this for you, the CRDs (and all CustomResource
> instances of those types, such as `Upgrade` and `UpgradeCampaign` objects) will
> remain in your cluster after `helm uninstall` unless you run the commands below.
> Note that other Kubernetes resources owned by the Helm release (Deployment,
> ServiceAccount, ConfigMaps, RBAC, etc.) are removed by `helm uninstall` as
> normal — only the CRDs and their instances are preserved. If you are
> uninstalling RUCC and do not plan to reinstall it, run these commands to clean
> up the CRDs completely.
>
> **The same behavior applies to `helm upgrade`**: if a future chart version
> removes a CRD from the chart's `crds/` directory, Helm will **not** delete that
> CRD (or its instances) from your cluster on upgrade. You must delete it
> manually if cleanup is desired.

**Warning**: This will delete all RUCC custom resources including upgrade campaigns and settings.

```bash
kubectl delete crd backups.rucc.cattle.io
kubectl delete crd checkruns.rucc.cattle.io
kubectl delete crd deploymentmonitors.rucc.cattle.io
kubectl delete crd helmoperationmonitors.rucc.cattle.io
kubectl delete crd metaservercaches.rucc.cattle.io
kubectl delete crd rke2upgrademonitors.rucc.cattle.io
kubectl delete crd restoreoperationhistories.rucc.cattle.io
kubectl delete crd restoreoperations.rucc.cattle.io
kubectl delete crd rollbackoperations.rucc.cattle.io
kubectl delete crd settings.rucc.cattle.io
kubectl delete crd upgradecampaigns.rucc.cattle.io
kubectl delete crd upgrades.rucc.cattle.io
```

> **Note**: Do **not** delete `plans.upgrade.cattle.io`. That CRD belongs to the
> [System Upgrade Controller (SUC)](https://github.com/rancher/system-upgrade-controller),
> which is an independent component that RUCC depends on for RKE2/K3s node upgrades.
> Deleting it will break SUC and disable cluster node upgrade capability. If you want
> to remove SUC entirely, follow the SUC project's own uninstall instructions.

### Clean Up RBAC (if not removed automatically)

```bash
kubectl delete clusterrole rucc-controller
kubectl delete clusterrolebinding rucc-controller
kubectl delete clusterrolebinding rucc-controller-admin
```

## Troubleshooting

### Controller Not Starting

**Symptoms**: Pod is in `CrashLoopBackOff` or `Error` state

**Solutions**:

1. Check logs:
   ```bash
   kubectl logs -n cattle-system -l app.kubernetes.io/name=rucc-controller --tail=100
   ```

2. Check events:
   ```bash
   kubectl get events -n cattle-system --sort-by='.lastTimestamp'
   ```

3. Verify CRDs are installed:
   ```bash
   kubectl get crd | grep rucc.cattle.io
   ```

4. Check RBAC permissions:
   ```bash
   kubectl auth can-i --list --as=system:serviceaccount:cattle-system:rucc-controller
   ```

### Meta-Server Connection Issues

**Symptoms**: Logs show connection timeouts or TLS errors

**Solutions**:

1. Test connectivity from within the cluster:
   ```bash
   kubectl run -it --rm debug --image=curlimages/curl --restart=Never -- \
     curl -v https://rucc.rancher.io
   ```

2. If TLS issues in lab environment, set:
   ```yaml
   controller:
     metaServer:
       insecureSkipVerify: true
   ```

3. Check firewall rules and network policies

### Webhook Configuration Issues

**Symptoms**: Admission webhook denying requests

**Solutions**:

1. Check webhook configuration:
   ```bash
   kubectl get validatingwebhookconfiguration rucc-controller-webhook
   ```

2. Verify webhook service:
   ```bash
   kubectl get svc rucc-controller-webhook -n cattle-system
   ```

3. Disable webhooks temporarily:
   ```bash
   helm upgrade rucc-controller supporttools/rucc-controller \
     --namespace cattle-system \
     --set webhook.enabled=false \
     --reuse-values
   ```

### Permission Denied Errors

**Symptoms**: Controller logs show RBAC permission errors

**Solutions**:

1. Verify cluster-admin binding exists:
   ```bash
   kubectl get clusterrolebinding rucc-controller-admin
   ```

2. If missing, enable in values:
   ```yaml
   rbac:
     clusterAdmin: true
   ```

3. Re-install with updated values:
   ```bash
   helm upgrade rucc-controller supporttools/rucc-controller \
     --namespace cattle-system \
     --set rbac.clusterAdmin=true \
     --reuse-values
   ```

### High Memory/CPU Usage

**Symptoms**: Controller consuming excessive resources

**Solutions**:

1. Check current resource usage:
   ```bash
   kubectl top pod -n cattle-system -l app.kubernetes.io/name=rucc-controller
   ```

2. Adjust resource limits:
   ```yaml
   resources:
     limits:
       cpu: 1000m
       memory: 512Mi
   ```

3. Disable tracing if enabled:
   ```yaml
   controller:
     tracing:
       enabled: false
   ```

### Upgrade Campaign Not Starting

**Symptoms**: Upgrade resources created but not progressing

**Solutions**:

1. Check Settings resource:
   ```bash
   kubectl get settings.rucc.cattle.io global -n cattle-system -o yaml
   ```

2. Verify auto-upgrade is enabled:
   ```yaml
   settings:
     autoUpgrade:
       enabled: true
   ```

3. Check controller logs for errors:
   ```bash
   kubectl logs -n cattle-system -l app.kubernetes.io/name=rucc-controller | grep -i upgrade
   ```

4. Verify meta-server is reachable and returning upgrade information

## Support

For additional help:

- **Documentation**: Check the full documentation at your organization's wiki
- **Logs**: Always include controller logs when reporting issues
- **GitHub Issues**: Report bugs and feature requests at the project repository
- **Slack/Teams**: Contact the RUCC development team via your organization's chat

## Additional Resources

- [Rancher Documentation](https://ranchermanager.docs.rancher.com/)
- [RKE2 Documentation](https://docs.rke2.io/)
- [Helm Documentation](https://helm.sh/docs/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)

---

**Version**: v1.0.0
**Last Updated**: 2026-04-15
**Maintained By**: RUCC Development Team